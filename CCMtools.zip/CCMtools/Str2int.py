import subprocess
import os
import pandas as pd
#import IPM
import sys

'''
Encoded values are translated back to their original values,
using the original input model csv source file.
arg1 = csv IPM file;   arg2 = int value csv file (transl from);   arg3 = str value csv vile (transl to)
'''
parameters = pd.read_csv(sys.argv[1], dtype=str)
str_csv = pd.read_csv(sys.argv[2], dtype=str)

for index, col in enumerate(parameters.columns.values):
   parameter_map = parameters[col].dropna().to_dict()
   rev_map = dict((v,k) for k,v in parameter_map.items())
   str_csv[col] =   str_csv[col].map(rev_map)

str_csv.to_csv(sys.argv[3])
