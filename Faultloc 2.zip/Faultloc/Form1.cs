﻿#region Using Directives

using System;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Collections.Generic; //drk
using System.Linq; 

#endregion

namespace Faultloc {
    public partial class Faultloc : Form {
        private FileInfo _fileInfo;
        private string[] _inputFile; // input file, to be converted to test array 
        private bool _loadCompleteFaultFile; // true = fault file loaded
        private bool _loadCompleteNominalFile; // true = nominal file loaded
        private int _nRowsFaultFile; // number of rows, fault file
        private int _nRowsNominalFile; // number of rows, nominal 
        private long _ncols; // number of columns, both files
        long C_n_2; //2-way combinations = C(n,2)
		long C_n_3; //3-way combinations = C(n,3)
		long C_n_4; //4-way combinations = C(n,4)in
		long C_n_5; //5-way combinations = C(n,5)
		long C_n_6; //6-way combinations = C(n,6)
                    //static int in_pass_bnd=0;    // threshold for reporting combination; 
                    //rpt if in fail but no more than in_pass_bnd occurrences in pass
        //static int in_fail_bnd = 1;               // threshold for reporting com; must be at least this many occurrences in fail
        //static double threshold = .00; // #occurrences in pass / #occurrences in fail
		//int[][] test_f; //tdm
		//int[][] test_p; //tdm
		private object[][] test_f; //tdm
        private object[][] test_p; //tdm
        private HashSet<string>[] val_set;   //set of values for each var; used to keep track of val count
        public HashSet<object> fail_not_pass = new HashSet<object>();    // set of row numbers of cases with a com in fail that is not in pass

        //private HashSet<int> pass_not_fail;    // set of row numbers of cases with a com in pass that is not in fail

        //public class Com1                                   //drk
        //{
        //    public object p1, v1;     // parm indexes and values
        //    public Com1(object i, object u) {
        //        this.p1 = i; this.v1 = u; 
        //    }

        //    public override bool Equals(object obj)
        //    {
        //        Com1 c1 = obj as Com1;
        //        return c1 != null && c1.p1 == this.p1 && c1.v1 == this.v1;
        //    }
        //    public override int GetHashCode()
        //    {
        //        return this.p1.GetHashCode() ^ this.v1.GetHashCode(); 
        //    }
        //}
        //private List<Com1> diff1way = new List<Com1>(); //drk
        struct Com1
        {
            public Com1(object i, object u) { p1 = i;  v1 = u; }
            object p1;
            object v1; 
        }
        private HashSet<Com1> diff1way = new HashSet<Com1>(); //drk


        public class Com2                                   //drk
        {
            public object p1, p2, v1, v2;     // parm indexes and values
            public Com2(object i, object j, object u, object v) {
                this.p1 = i; this.p2 = j; this.v1 = u; this.v2 = v;
            }
            public override bool Equals(object obj)
            {
                Com2 c2 = obj as Com2;
                return c2 != null && 
                c2.p1 == this.p1 && c2.p2 == this.p2 &&
                c2.v1 == this.v1 && c2.v2 == this.v1;
            }
            public override int GetHashCode()
            {
                return this.p1.GetHashCode() ^ this.p2.GetHashCode() ^ this.v1.GetHashCode() ^ this.v2.GetHashCode();
            }
        }
        //private List<Com2> diff2way = new List<Com2>(); //drk
        private HashSet<Com2> diff2way = new HashSet<Com2>(); //drk


        public class Com3 {                                 //drk
            public object p1, p2, p3, v1, v2, v3;
            public Com3(object i, object j, object k, object u, object v, object w) {
                this.p1 = i; this.p2 = j; this.p3 = k;
                this.v1 = u; this.v2 = v; this.v3 = w;
            }
        }
        //private List<Com3> diff3way = new List<Com3>(); //drk
        private HashSet<Com3> diff3way = new HashSet<Com3>(); //drk


        public class Com4 {                                 //drk
            public object p1, p2, p3, p4, v1, v2, v3, v4;
            public Com4(object i, object j, object k, object l, object u, object v, object w, object x) {
                this.p1 = i; this.p2 = j; this.p3 = k; this.p4 = l;
                this.v1 = u; this.v2 = v; this.v3 = w; this.v4 = x;

            }
        }
        //private List<Com4> diff4way = new List<Com4>(); //drk
        private HashSet<Com4> diff4way = new HashSet<Com4>(); //drk


        public class Com5 {                                 //drk
			public object p1, p2, p3, p4, p5, v1, v2, v3, v4, v5;
			public Com5(object i, object j, object k, object l, object m, object u, object v, object w, object x, object y) {
				this.p1 = i; this.p2 = j; this.p3 = k; this.p4 = l; this.p5 = m;
				this.v1 = u; this.v2 = v; this.v3 = w; this.v4 = x; this.v5 = y;

			}
		}
		//private List<Com5> diff5way = new List<Com5>(); //drk
        private HashSet<Com5> diff5way = new HashSet<Com5>(); //drk



        public Faultloc() {
            InitializeComponent();
            SetupMultiWayTabStates();
        }

        private void ClearUI() {
            ResetTextBox(rptBox2way);
            ResetTextBox(rptBox3way);
            ResetTextBox(rptBox4way);
            ResetTextBox(rptBox5way);
            ResetTextBox(rptBox6way);

            ResetTextBox(statBox2way);
            ResetTextBox(statBox3way);
            ResetTextBox(statBox4way);
            ResetTextBox(statBox5way);
            ResetTextBox(statBox6way);

            ResetProgressBar(progress2way);
            ResetProgressBar(progress3way);
            ResetProgressBar(progress4way);
            ResetProgressBar(progress5way);
            ResetProgressBar(progress6way);
			diff2way.Clear();
			diff3way.Clear();
			diff4way.Clear();
			diff5way.Clear();
            fail_not_pass.Clear(); 

			//val_set.Initialize(); 
		}

        private static void ResetTextBox(TextBox textBox) {
            textBox.Text = string.Empty;
        }

        private static void ResetProgressBar(ProgressBar progressBar) {
            progressBar.Value = 0;
            progressBar.Refresh();
        }

        private void Reset() {
            _loadCompleteFaultFile = false;
            _loadCompleteNominalFile = false;

            ResetTextBox(txtFaultContents);
            ClearUI();
            diff2way.Clear();
            diff3way.Clear();
            diff4way.Clear();
			diff5way.Clear();

			fail_not_pass.Clear();
			//val_set.Initialize(); 
		}

        private void BtnLoadFaultFile_Click(object sender, EventArgs e) {
            var lastlen = 0; //used to check that each line of input file same as previous  
            var sep = new[] { ',' };
            String line;
            String[] values;

            Reset();

            var dr = openFileDialog.ShowDialog();
            if (dr == DialogResult.OK) {
                // determine nrows and ncols w/ out user 
                try {
                    var sr = new StreamReader(openFileDialog.FileName);

                    var i = 0;
                    while ((line = sr.ReadLine()) != null) {
                        values = line.Split(sep, StringSplitOptions.RemoveEmptyEntries);
                        _ncols = values.Length;
                        if (i > 0 && _ncols != lastlen || _ncols < 2) {
                            MessageBox.Show(
                                "Invalid input file;\n must have same number of columns all rows; # cols > 1; line " + i);
                            return;
                        }
                        else {
                            lastlen = (int)_ncols;
                        }
                        i++;
                    }
                    _nRowsFaultFile = i;

                    sr.Close();
                }
                catch {
                    MessageBox.Show(
                        "File cannot be opened for initial test and parameter counting.\nFile may be open in another process.");
                }
            }
            // file of faulty or target tests now loaded
            // display file
            if (dr == DialogResult.OK)
                try {
                    var sr = new StreamReader(openFileDialog.FileName);

                    _inputFile = new string[_nRowsFaultFile]; // allocate memory for file
                    // allocate array for in-memory storage of tests
                    test_f = new object[_nRowsFaultFile][]; //changed int to obj tdm
                    for (var j = 0; j < _nRowsFaultFile; j++) {
                        test_f[j] = new object[_ncols];
                    } //changed int to obj tdm

                    val_set = new HashSet<string>[_ncols];  //drk
                    for (int k = 0; k < _ncols; k++) val_set[k] = new HashSet<string>();    //drk
                    fail_not_pass.Clear(); 

                    var i = 0;
                    while (i < _nRowsFaultFile && ((line = sr.ReadLine()) != null)) {
                        _inputFile[i] = line; // save each test file line in memory
                        values = _inputFile[i].Split(sep, StringSplitOptions.RemoveEmptyEntries);
                        // check that number of input parameters matches number specified by user
                        if (values.Length != _ncols) {
                            MessageBox.Show("Number of columns must be same. Class file: " + _ncols + ". Nominal file: " +
                                            values.Length + "line ", i.ToString());
                            return;
                        }


                        for (var j = 0; j < _ncols; j++) {
                            test_f[i][j] = values[j];   //Convert.ToInt32(values[j]); tdm
                            if (i != 0) val_set[j].Add(values[j]);  // set of values for each variable; skip first line //drk
                        }

                        i++;
                    }

                    var ntmp = i;

                    //userMsg.Text = ntmp.ToString() + " tests, " + ncols.ToString() + " parameters loaded";
                    if (ntmp < _nRowsFaultFile) {
                        // notify user that number of tests is different from number specified by user
                        MessageBox.Show(" ** Tests loaded less than specified! **");
                        _nRowsFaultFile = ntmp; //reset in case file contained fewer rows than specified by user
                    }
                    var s = openFileDialog.FileName;
                    _fileInfo = new FileInfo(s); //s.Substring(s.LastIndexOf("\\") + 1);
                    txtFaultInfo.Text = string.Format("Class file {0}; rows={1}; cols={2}", _fileInfo.Name,
                                                      (_nRowsFaultFile-1), _ncols);
                    sr.Close();
                    _loadCompleteFaultFile = true;
                }
                catch {
                    MessageBox.Show(
                        "File cannot be opened.\nCheck number of tests and parameters.\nFile may be open in another process.");
                }
            if (_loadCompleteFaultFile) {
                //tdm//for (int i = 0; i < ncols; i++) fBox.Text = fBox.Text + i%10 + " "; fBox.Text += Environment.NewLine;
                //tdm//for (int i = 0; i < ncols; i++) fBox.Text = fBox.Text + "  "; fBox.Text += Environment.NewLine;
                var sb = new StringBuilder();
                for (var j = 0; j < _nRowsFaultFile; j++) {
                    for (var k = 0; k < _ncols; k++) {
                        sb.AppendFormat("{0}", test_f[j][k].ToString().PadRight(25 - test_f[j][k].ToString().Length));
                        //Stringvalue.PadRight(int, char)
                        //txtFaultContents.Text = txtFaultContents.Text + test_f[j][k].ToString().PadRight(25 - test_f[j][k].ToString().Length) + " " + "\t";
                        //if ((test_f[j][k].ToString().Length < 10)) fBox.Text += "\t";
                    }
                    sb.Append(Environment.NewLine);
                }
                txtFaultContents.Text = sb.ToString();
            }
        }

        private int strlen(Func<string> func) {
            throw new NotImplementedException();
        }

        private void nomButton_Click(object sender, EventArgs e) {
            //var lastlen = 0; //used to check that each line of input file same as previous  
            var sep = new[] { ',' };
            var line = "";
            String[] values = null;
            _loadCompleteNominalFile = false;

            btnTest.Enabled = _loadCompleteNominalFile;

            if (!_loadCompleteFaultFile) {
                MessageBox.Show("Load class file first.");
                return;
            }
            var dr = openFileDialog.ShowDialog();
            if (dr == DialogResult.OK) {
                // determine nrows and ncols w/ out user 
                try {
                    var sr = new StreamReader(openFileDialog.FileName);

                    var i = 0;
                    while ((line = sr.ReadLine()) != null) {
                        values = line.Split(sep, StringSplitOptions.RemoveEmptyEntries);
                        if (values.Length != _ncols) {
                            MessageBox.Show("N columns not equal. Class: " + _ncols + ". Nominal: " +
                                            values.Length + ". line " + i.ToString());
                            return;
                        }
                        i++;
                    }
                    _nRowsNominalFile = i;

					// compute number of t-way variable combinations = C(n,t)

					var s = openFileDialog.FileName;
                    _fileInfo = new FileInfo(s);

                    C_n_2 = _ncols * (_ncols - 1) / 2;
                    C_n_3 = _ncols * (_ncols - 1) * (_ncols - 2) / 6;
                    C_n_4 = _ncols * (_ncols - 1) * (_ncols - 2) * (_ncols - 3) / 24;
                    C_n_5 = _ncols * (_ncols - 1) * (_ncols - 2) * (_ncols - 3) * (_ncols - 4) / 120;
                    C_n_6 = _ncols * (_ncols - 1) * (_ncols - 2) * (_ncols - 3) * (_ncols - 4) * (_ncols - 5) / 720;

					txtNominalInfo.Text = string.Format
                        ("Nominal file {0}; rows={1}; cols={2} ||     2-way: {3:N0}      3-way: {4:N0}      4-way: {5:N0}      5-way: {6:N0}      6-way: {7:N0} ",
                         _fileInfo.Name,  (_nRowsNominalFile-1), _ncols, C_n_2, C_n_3, C_n_4,C_n_5,C_n_6
                        );
                    sr.Close();
                }
                catch {
                    MessageBox.Show(  "File cannot be opened for initial test and parameter counting.\nFile may be open in another process.");
                }
            }
            // file of faulty or target tests now loaded
            // display file
            if (dr == DialogResult.OK)
                try {
                    ClearUI();

                    var sr = new StreamReader(openFileDialog.FileName);
                    var s = openFileDialog.FileName;
                    _fileInfo = new FileInfo(s);

                    _inputFile = new string[_nRowsFaultFile]; // allocate memory for file
                    // allocate array for in-memory storage of tests
                    test_p = new object[_nRowsNominalFile][]; //changed int to obj tdm
                    for (var j = 0; j < _nRowsNominalFile; j++) {
                        test_p[j] = new object[_ncols];
                    } //changed int to obj tdm

                    var i = 0;
                    while (i < _nRowsNominalFile && ((line = sr.ReadLine()) != null)) {
                        //infile[i] = line;				// save each test file line in memory
                        values = line.Split(sep, StringSplitOptions.RemoveEmptyEntries);
                        // check that number of input parameters matches number specified by user
                        if (values.Length != _ncols) {
                            AlertUser("Alert",
                                      string.Format(
                                          "Number of columns must be same. Class file: {0} Nominal file: {1}", _ncols,
                                          values.Length));
                            return;
                        }
                    for (var j = 0; j < _ncols; j++) {
							test_p[i][j] = (values[j]); //Convert.ToInt32(values[j]);
							if (i != 0) val_set[j].Add(values[j]);  // set of values for each variable; skip first line //drk
						} 
					i++;
                    }
                    var ntmp = i;

                    //userMsg.Text = ntmp.ToString() + " tests, " + ncols.ToString() + " parameters loaded";
                    if (ntmp < _nRowsNominalFile) {
                        // notify user that number of tests is different from number specified by user
                        AlertUser("Alert", "Tests loaded less than specified!");
                        _nRowsNominalFile = ntmp; //reset in case file contained fewer rows than specified by user
                    }

                    sr.Close();
                    _loadCompleteNominalFile = true;
                    btnTest.Enabled = true;
                }
                catch {
                    AlertUser("Unable to Load File",
                              "File cannot be opened.\nCheck number of tests and parameters.\nFile may be open in another process.");
                }
        }

        //******************************************************************************************************
        private void TwoWayTest() {
            var sb = new StringBuilder();
            double[,] heatmap2 = new double[_ncols, _ncols];

            //var possible_coms = 0; // number of possible fault-triggering combinations
            //var total_coms = 0; // total number of combinations
            var t2_settings = 0;    //total possible 2-way settings of variables

            //progress2way.Step = (int)(800 / (float)(_ncols - 1));
            //progress2way.Value = 0;
            //progress2way.Refresh();
            //progress2way.PerformStep();
            // scan test_p for combinations that occur in test_f;  
            //  count and rpt number of times each occurs in test_p
            for (var i = 0; i < _ncols - 1; i++) {
                for (var j = i + 1; j < _ncols; j++) { //   foreach 2-way combination:
                     t2_settings += val_set[i].Count * val_set[j].Count;
                    //possible_coms++; 
                    // for each combination in Fail, count num times in Pass. 
                    // set up for only one line in Class/fail file
                    for (var rf = 1; rf < _nRowsFaultFile; rf++) {  // nrows should be 2 (w/ header)
                        int in_pass_cnt = 0;
						for (var rp = 1; rp < _nRowsNominalFile; rp++) {
							if (test_f[rf][i].Equals(test_p[rp][i]) && test_f[rf][j].Equals(test_p[rp][j])) {
                                in_pass_cnt++;
                            }
                        }
                        heatmap2[i, j] = ((double)in_pass_cnt / (_nRowsNominalFile - 1));
                        // rpt:  num times in nominal, occurrences/total rows nominal, combination
                        sb.AppendFormat("{0:D4} occurrences = {1:0.000} of cases, {2},{3} = {4},{5}\n",
                                        in_pass_cnt, 
                                        ((double)in_pass_cnt/(_nRowsNominalFile-1)),
                                        test_f[0][i],
                                        test_f[0][j],
                                        test_f[rf][i],
                                        test_f[rf][j]);

                        // save 2-way coms for checking in 3-way  -- drk
                        Com2 tmp2 = new Com2(i, j, test_f[rf][i], test_f[rf][j]);  //drk
                        diff2way.Add(tmp2);  //drk
                        Com1 tmp1i = new Com1(i, test_f[rf][i]);
                        Com1 tmp1j = new Com1(j, test_f[rf][j]);
                        diff1way.Add(tmp1i);
                        diff1way.Add(tmp1j);
                        
                    }
                }
                //if (i % 8 == 0) {progress2way.PerformStep();}

            }
            List<string> items = new List<string>(sb.ToString().Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries));
            items.Sort();
            items.Distinct().ToList();
            //items.Reverse();
            sb = new StringBuilder(string.Join("\n", items.ToArray()));
            sb.AppendFormat("\n--------------- \n");


            //***********
            // now report single value combinations
            
            for (var i = 0; i < _ncols; i++) {
                for (var rf = 1; rf < _nRowsFaultFile; rf++) {  // nrows should be 2 (w/ header)
                    int in_pass_cnt = 0;
                    for (var rp = 1; rp < _nRowsNominalFile; rp++) {
                        if (test_f[rf][i].Equals(test_p[rp][i]) ) {
                            in_pass_cnt++;
                        }
                    }
                    // rpt:  num times in nominal, occurrences/total rows nominal, combination
                    sb.AppendFormat("{0:D4} occurrences = {1:0.000} of cases, {2} = {3}\n",
                                    in_pass_cnt,
                                    ((double)in_pass_cnt / (_nRowsNominalFile - 1)),
                                    test_f[0][i],
                                    test_f[rf][i]);              
                }
            }
            /// 
            //List<string> 
            items = new List<string>(sb.ToString().Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries));
            items.Sort();
            items.Distinct().ToList(); 
            //items.Reverse();
            sb = new StringBuilder(string.Join("\n", items.ToArray()));
            ///  
            statBox2way.Text = GetSboxComboText((int)C_n_2, t2_settings);
            rptBox2way.Text = sb.ToString();
            System.IO.StreamWriter fl2_file = new System.IO.StreamWriter("/Users/kuhn/AIML/2way-out.csv");  //drk
            fl2_file.WriteLine(sb.ToString());
            fl2_file.Close();

            // output heat map csv file for Excel
            System.IO.StreamWriter fl2h_file = new System.IO.StreamWriter("/Users/kuhn/AIML/2way-heatmap.csv");  //drk
            var sh = new StringBuilder();
            sh.AppendFormat("Heatmap, ");
            for (int i = 1; i < _ncols; i++) { sh.AppendFormat("{0}, ", test_f[0][i]); }   // write header
            sh.AppendFormat("\n");
            for (int i = 0; i < _ncols - 1; i++) {
                sh.AppendFormat("{0}, ", test_f[0][i]); // class name
                for (int k = 0; k < i; k++) sh.AppendFormat(" ,"); 
                for (int j = i+1; j < _ncols; j++) {
                    sh.AppendFormat("{0}, ", heatmap2[i,j]);
                }
                sh.AppendFormat("\n");
            }
            fl2h_file.WriteLine(sh.ToString());
            fl2h_file.Close();


        }


        //*************************************************************************************************
        private void ThreeWayTest() {
            var sb = new StringBuilder();
            //var possible_coms = 0; // number of possible fault-triggering combinations
            var total_coms = 0; // total number of combinations
            var t3_settings = 0;

            progress3way.Step = (int)(800 / (float)(_ncols - 1));
            progress3way.Value = 0;
            progress3way.Refresh();
            progress3way.PerformStep();
            // scan test_p for combinations that occur in test_f; remove from test_f any combinations that 
            // also occur in test_p.  If these occur in test_p, they cannot be triggering fault. 
            for (var i = 0; i < _ncols - 2; i++) {
                for (var j = i + 1; j < _ncols - 1; j++) {
                    for (var k = j + 1; k < _ncols; k++) {
                        total_coms++;
                        t3_settings += val_set[i].Count * val_set[j].Count * val_set[k].Count;

                        for (var rf = 1; rf < _nRowsFaultFile; rf++) {  // nrows should be 2 (w/ header)
                            int in_pass_cnt = 0;
                            for (var rp = 1; rp < _nRowsNominalFile; rp++) {
                                if (test_f[rf][i].Equals(test_p[rp][i]) && test_f[rf][j].Equals(test_p[rp][j])
                                   && test_f[rf][k].Equals(test_p[rp][k])) {
                                    in_pass_cnt++;
                                }
                            }
                            // rpt:  num times in nominal, occurrences/total rows nominal, combination
                            sb.AppendFormat("{0:D5} occurrences = {1:0.000} of cases, {2},{3},{4} = {5},{6},{7}\n",
                                            in_pass_cnt,
                                            ((double)in_pass_cnt / (_nRowsNominalFile - 1)),
                                            test_f[0][i],
                                            test_f[0][j],
                                            test_f[0][k],
                                            test_f[rf][i],
                                            test_f[rf][j],
                                            test_f[rf][k]);

                            // save 2-way coms for checking in 3-way  -- drk
                            Com3 tmp3 = new Com3(i, j, k, test_f[rf][i], test_f[rf][j], test_f[rf][k]);  //drk
                            diff3way.Add(tmp3);  //drk
                            Com1 tmp1i = new Com1(i, test_f[rf][i]);
                            Com1 tmp1j = new Com1(j, test_f[rf][j]);
                            Com1 tmp1k = new Com1(k, test_f[rf][k]);
                            diff1way.Add(tmp1i);
                            diff1way.Add(tmp1j);
                            diff1way.Add(tmp1k);
                        }
                    }
                }
                if (i % 8 == 0) {progress3way.PerformStep();}
            }
                    List<string> items = new List<string>(sb.ToString().Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries));
                    items.Sort();
                    //items.Reverse();
                    sb = new StringBuilder(string.Join("\n", items.ToArray()));
                    sb.AppendFormat("\n--------------- \n");

                    statBox3way.Text = GetSboxComboText((int)C_n_3, t3_settings);
                    rptBox3way.Text = sb.ToString();
            System.IO.StreamWriter fl2_file = new System.IO.StreamWriter("/Users/kuhn/AIML/3way-out.csv");  //drk
            fl2_file.WriteLine(sb.ToString());
            fl2_file.Close();

            //-----------------------
        }

        //*************************************************************************************************
        private void FourWayTest() {
            var sb = new StringBuilder();
            //var possible_coms = 0; // number of possible fault-triggering combinations
            var total_coms = 0; // total number of combinations
            var t4_settings = 0;

            progress4way.Step = (int)(800 / (float)(_ncols - 1));
            progress4way.Value = 0;
            progress4way.Refresh();
            progress4way.PerformStep();
            // scan test_p for combinations that occur in test_f; remove from test_f any combinations that 
            // also occur in test_p.  If these occur in test_p, they cannot be triggering fault. 
            for (var i = 0; i < _ncols - 3; i++) {
                for (var j = i + 1; j < _ncols - 2; j++) {
                    for (var k = j + 1; k < _ncols - 1; k++) {
                        for (var l = k + 1; l < _ncols; l++) {
                            total_coms++;
                            t4_settings += val_set[i].Count * val_set[j].Count * val_set[k].Count * val_set[l].Count;

                            for (var rf = 1; rf < _nRowsFaultFile; rf++) {  // nrows should be 2 (w/ header)
                                int in_pass_cnt = 0;
                                for (var rp = 1; rp < _nRowsNominalFile; rp++) {
                                    if (test_f[rf][i].Equals(test_p[rp][i]) && test_f[rf][j].Equals(test_p[rp][j])
                                       && test_f[rf][k].Equals(test_p[rp][k]) && test_f[rf][l].Equals(test_p[rp][l])) {
                                        in_pass_cnt++;
                                    }
                                }
                                // rpt:  num times in nominal, occurrences/total rows nominal, combination
                                sb.AppendFormat("{0:D5} occurrences = {1:0.000} of cases, {2},{3},{4},{5} = {6},{7},{8},{9}\n",
                                            in_pass_cnt,
                                            ((double)in_pass_cnt / (_nRowsNominalFile - 1)),
                                            test_f[0][i],
                                            test_f[0][j],
                                            test_f[0][k],
                                            test_f[0][l],
                                            test_f[rf][i],
                                            test_f[rf][j],
                                            test_f[rf][k],
                                            test_f[rf][l]);

                                // save 2-way coms for checking in 3-way  -- drk
                                Com4 tmp4 = new Com4(i, j, k, l, test_f[rf][i], test_f[rf][j], test_f[rf][k], test_f[rf][l]);  //drk
                                diff4way.Add(tmp4);  //drk
                                Com1 tmp1i = new Com1(i, test_f[rf][i]);
                                Com1 tmp1j = new Com1(j, test_f[rf][j]);
                                Com1 tmp1k = new Com1(k, test_f[rf][k]);
                                Com1 tmp1l = new Com1(l, test_f[rf][l]);
                                diff1way.Add(tmp1i);
                                diff1way.Add(tmp1j);
                                diff1way.Add(tmp1k);
                                diff1way.Add(tmp1l);
                            }
                        }
                    }
                }
                if (i % 8 == 0) { progress4way.PerformStep(); }
            }
            List<string> items = new List<string>(sb.ToString().Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries));
            items.Sort();
            //items.Reverse();
            sb = new StringBuilder(string.Join("\n", items.ToArray()));
            sb.AppendFormat("\n--------------- \n");

            statBox4way.Text = GetSboxComboText((int)C_n_4, t4_settings);
            rptBox4way.Text = sb.ToString();
            System.IO.StreamWriter fl2_file = new System.IO.StreamWriter("/Users/kuhn/AIML/4way-out.csv");  //drk
            fl2_file.WriteLine(sb.ToString());
            fl2_file.Close();

            //-----------------------
        }



//***************************************************************************************
        private void FiveWayTest() {
            var start = DateTime.UtcNow;

            var sb = new StringBuilder();
            //var possible_coms = 0; // number of possible fault-triggering combinations
            var total_coms = 0; // total number of combinations
            var t5_settings = 0;

            progress5way.Step = (int)(800 / (float)(_ncols - 1));
            progress5way.Value = 0;
            progress5way.Refresh();
            progress5way.PerformStep();
            // scan test_p for combinations that occur in test_f; remove from test_f any combinations that 
            // also occur in test_p.  If these occur in test_p, they cannot be triggering fault. 
            for (var i = 0; i < _ncols - 4; i++) {
                for (var j = i + 1; j < _ncols - 3; j++) {
                    for (var k = j + 1; k < _ncols - 2; k++) {
                        for (var l = k + 1; l < _ncols - 1; l++) {
                            for (var m = l + 1; m < _ncols; m++) {
                                total_coms++;
								t5_settings += val_set[i].Count * val_set[j].Count * val_set[k].Count * val_set[l].Count * val_set[m].Count;

                                for (var rf = 1; rf < _nRowsFaultFile; rf++) {  // nrows should be 2 (w/ header)
                                    int in_pass_cnt = 0;
                                    for (var rp = 1; rp < _nRowsNominalFile; rp++) {
                                        if (test_f[rf][i].Equals(test_p[rp][i]) && test_f[rf][j].Equals(test_p[rp][j])
                                           && test_f[rf][k].Equals(test_p[rp][k]) && test_f[rf][l].Equals(test_p[rp][l])
                                           && test_f[rf][m].Equals(test_p[rp][m])) {
                                            in_pass_cnt++;
                                        }
                                    }
                                    // rpt:  num times in nominal, occurrences/total rows nominal, combination
                                    sb.AppendFormat("{0:D5} occurrences = {1:0.000} of cases, {2},{3},{4},{5},{6} = {7},{8},{9},{10},{11}\n",
                                                in_pass_cnt,
                                                ((double)in_pass_cnt / (_nRowsNominalFile - 1)),
                                                test_f[0][i],
                                                test_f[0][j],
                                                test_f[0][k],
                                                test_f[0][l],
                                                test_f[0][m],
                                                test_f[rf][i],
                                                test_f[rf][j],
                                                test_f[rf][k],
                                                test_f[rf][l],
                                                test_f[rf][m]);

                                    // save 5-way coms for checking in 6-way  -- drk
                                    Com5 tmp5 = new Com5(i, j, k, l,m, test_f[rf][i], test_f[rf][j], 
                                                         test_f[rf][k], test_f[rf][l], test_f[rf][m]);  //drk
                                    diff5way.Add(tmp5);  //drk
                                    Com1 tmp1i = new Com1(i, test_f[rf][i]);
                                    Com1 tmp1j = new Com1(j, test_f[rf][j]);
                                    Com1 tmp1k = new Com1(k, test_f[rf][k]);
                                    Com1 tmp1l = new Com1(l, test_f[rf][l]);
                                    Com1 tmp1m = new Com1(m, test_f[rf][m]);
                                    diff1way.Add(tmp1i);
                                    diff1way.Add(tmp1j);
                                    diff1way.Add(tmp1k);
                                    diff1way.Add(tmp1l);
                                    diff1way.Add(tmp1m);
                                }

                                //// for each combination in Fail, determine if also in Pass. Report coms in Fail but not in Pass
                                //for (var rf = 1; rf < _nRowsFaultFile; rf++) {
                                //                           var in_pass = false; // combination i,j,k,l not yet seen in Pass file
                                //                           for (var rp = 1; !in_pass && rp < _nRowsNominalFile; rp++) {
                                //                               //if (test_f[rf][i] == test_p[rp][i] && test_f[rf][j] == test_p[rp][j]//tdm
                                //                               //&& test_f[rf][k] == test_p[rp][k] && test_f[rf][l] == test_p[rp][l] && test_f[rf][m] == test_p[rp][m])//tdm
                                //                               if (test_f[rf][i].Equals(test_p[rp][i]) &&
                                //                                   test_f[rf][j].Equals(test_p[rp][j]) &&
                                //                                   test_f[rf][k].Equals(test_p[rp][k]) &&
                                //                                   test_f[rf][l].Equals(test_p[rp][l]) &&
                                //                                   test_f[rf][m].Equals(test_p[rp][m])) {
                                //                                   in_pass = true;
                                //                               }
                                //                               // in_pass == combination [rf,i,j,k,l] occurs in Pass file also
                                //                           }
                                //// in_pass && com found in Pass file OR !in_pass and com not in any test of Pass file
                                //if (!in_pass) {
                                //	fail_not_pass.Add(rf);   // case rf has a com that is in fail file but not in pass
                                //}
                                //                          if (!in_pass) {
                                //                              // first make sure not already reported
                                //                              var flag = false;
                                //                              if (rf > 0) {
                                //                                  //see if it's in previous row of fault file
                                //                                  for (var i0 = 0; !flag && i0 < rf; i0++) {
                                //                                      //if (test_f[rf][i] == test_f[i0][i] && test_f[rf][j] == test_f[i0][j]//tdm
                                //                                      //&& test_f[rf][k] == test_f[i0][k] && test_f[rf][l] == test_f[i0][l]//tdm
                                //                                      //&& test_f[rf][m] == test_f[i0][m]) flag = true; //tdm
                                //                                      if (test_f[rf][i].Equals(test_f[i0][i]) &&
                                //                                          test_f[rf][j].Equals(test_f[i0][j]) &&
                                //                                          test_f[rf][k].Equals(test_f[i0][k]) &&
                                //                                          test_f[rf][l].Equals(test_f[i0][l]) &&
                                //                                          test_f[rf][m].Equals(test_f[i0][m])) {
                                //                                          flag = true;
                                //                                      }
                                //                                  }
                                //                              }
                                //                              // see if known 4way is contained in it --drk
                                //                              foreach (Com4 com in diff4way) { //drk
                                //                                  if (com.p1.Equals(i) && com.p2.Equals(j) && com.p3.Equals(k) && com.p3.Equals(l) &&
                                //                                      com.v1.Equals(test_f[rf][i]) && com.v2.Equals(test_f[rf][j]) && com.v3.Equals(test_f[rf][k]) && com.v3.Equals(test_f[rf][l]) ||
                                //                                      com.p1.Equals(i) && com.p2.Equals(j) && com.p3.Equals(k) && com.p3.Equals(m) &&
                                //                                      com.v1.Equals(test_f[rf][i]) && com.v2.Equals(test_f[rf][j]) && com.v3.Equals(test_f[rf][k]) && com.v3.Equals(test_f[rf][m]) ||
                                //                                      com.p1.Equals(i) && com.p2.Equals(j) && com.p3.Equals(l) && com.p3.Equals(m) &&
                                //                                      com.v1.Equals(test_f[rf][i]) && com.v2.Equals(test_f[rf][j]) && com.v3.Equals(test_f[rf][l]) && com.v3.Equals(test_f[rf][m]) ||
                                //                                      com.p1.Equals(i) && com.p2.Equals(k) && com.p3.Equals(l) && com.p3.Equals(m) &&
                                //                                      com.v1.Equals(test_f[rf][i]) && com.v2.Equals(test_f[rf][k]) && com.v3.Equals(test_f[rf][l]) && com.v3.Equals(test_f[rf][m]) ||
                                //                                      com.p1.Equals(j) && com.p2.Equals(k) && com.p3.Equals(l) && com.p3.Equals(m) &&
                                //                                      com.v1.Equals(test_f[rf][j]) && com.v2.Equals(test_f[rf][k]) && com.v3.Equals(test_f[rf][l]) && com.v3.Equals(test_f[rf][m])
                                //                                     )
                                //                                      flag = true;
                                //                              }

                                //                              if (!flag) {
                                //                                  int fail_cnt = 0;
                                //                                  for (var m0 = 1; m0 < _nRowsFaultFile; m0++) {
                                //                                      if (test_f[rf][i].Equals(test_f[m0][i]) &&
                                //                                          test_f[rf][j].Equals(test_f[m0][j]) &&
                                //                                          test_f[rf][k].Equals(test_f[m0][k]) &&
                                //                                          test_f[rf][l].Equals(test_f[m0][l]) &&
                                //                                          test_f[rf][m].Equals(test_f[m0][m]))
                                //                                          fail_cnt++;
                                //                                  }
                                //                                  // Fix format to have commas, also show headers like 2-4 way tests
                                //                                  sb.AppendFormat(
                                //                                      "{13}, = {12:0.0%}, line{0}:, {1}, {2}, {3}, {4}, {5}, =, {6}, {7}, {8}, {9}, {10}{11}",
                                //                                      rf,
                                //                                      test_f[0][i],
                                //                                      test_f[0][j],
                                //                                      test_f[0][k],
                                //                                      test_f[0][l],
                                //                                      test_f[0][m],
                                //                                      test_f[rf][i],
                                //                                      test_f[rf][j],
                                //                                      test_f[rf][k],
                                //                                      test_f[rf][l],
                                //                                      test_f[rf][m],
                                //                                      Environment.NewLine,
                                //                                      ((double)fail_cnt / (_nRowsFaultFile - 1)),
                                //                                      fail_cnt);
                                //                                  possible_coms++;
                                //	// save 5-way coms for checking in 6-way  -- drk
                                //	Com5 tmp5 = new Com5(i, j, k, l, m, test_f[rf][i], test_f[rf][j], test_f[rf][k], test_f[rf][l], test_f[rf][m]);  //drk
                                //	diff5way.Add(tmp5);  //drk
                                //}
                                //    }
                                //    // combination [rf,i,j,k,,ml]  either found in Pass file OR not found and reported
                                //}
                                // for all tests rf in Fail, combination [rf,i,j,k,l,m]  either found in Pass file OR not found and reported
                            }
                        }
                    }
                }
                if (i % 8 == 0) {
                    progress5way.PerformStep();
                }
            }

            List<string> items = new List<string>(sb.ToString().Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries));
            items.Sort();
            //items.Reverse();
            sb = new StringBuilder(string.Join("\n", items.ToArray()));
            sb.AppendFormat("\n--------------- \n");

            statBox5way.Text = GetSboxComboText((int)C_n_5, t5_settings);
            rptBox5way.Text = sb.ToString();
            System.IO.StreamWriter fl2_file = new System.IO.StreamWriter("/Users/kuhn/AIML/5way-out.csv");  //drk
            fl2_file.WriteLine(sb.ToString());
            fl2_file.Close();


            //         statBox5way.Text = GetSboxComboText(possible_coms,t5_settings);
            //         sb.AppendFormat("--------------- {0}", Environment.NewLine);
            //sb.AppendFormat("Fail not pass = {1} {0}", Environment.NewLine, fail_not_pass.Count);
            //foreach (int i in fail_not_pass) sb.AppendFormat(" {0}", i);

            //sb.AppendFormat("--------------- {0}", Environment.NewLine);

            //var ofil = new StringBuilder();      //drk
            //foreach (Com5 com in diff5way) {
            //	for (int i = 0; i < _ncols; i++) {
            //		if (com.p1.Equals(i)) ofil.AppendFormat("{0},", com.v1.ToString());
            //		else if (com.p2.Equals(i)) ofil.AppendFormat("{0},", com.v2.ToString());
            //		else if (com.p3.Equals(i)) ofil.AppendFormat("{0},", com.v3.ToString());
            //		else if (com.p4.Equals(i)) ofil.AppendFormat("{0},", com.v4.ToString());
            //		else if (com.p5.Equals(i) && i < _ncols - 1) ofil.AppendFormat("{0},", com.v5.ToString());
            //		else if (com.p5.Equals(i) && i == _ncols - 1) ofil.AppendFormat("{0}", com.v5.ToString());

            //		else if (i < _ncols - 1) ofil.AppendFormat(".*,");
            //		else ofil.AppendFormat(".*");
            //	}
            //	ofil.AppendFormat("\n");
            //}
            //System.IO.StreamWriter fl_file = new System.IO.StreamWriter("/Users/kuhn/5way-coms.csv");  //drk
            //fl_file.WriteLine(ofil.ToString());
            //fl_file.Close();

            //rptBox5way.Text = sb.ToString();            System.IO.StreamWriter fl2_file = new System.IO.StreamWriter("/Users/kuhn/5way-out.csv");  //drk
            //fl2_file.WriteLine(sb.ToString());
            //fl2_file.Close();

            //var end = DateTime.UtcNow;
            //MessageBox.Show(string.Format("Processing Time: {0}", end - start));

        }

        private void SixWayTest() {
            var sb = new StringBuilder();
            var possible_coms = 0; // number of possible fault-triggering combinations
            var total_coms = 0; // total number of combinations
            var t6_settings = 0; 

            progress6way.Step = (int)(800 / (float)(_ncols - 1));
            progress6way.Value = 0;
            progress6way.Refresh();
            progress6way.PerformStep(); //
            // scan test_p for combinations that occur in test_f; remove from test_f any combinations that 
            // also occur in test_p.  If these occur in test_p, they cannot be triggering fault. 
            for (var i = 0; i < _ncols - 5; i++) {
                for (var j = i + 1; j < _ncols - 4; j++) {
                    for (var k = j + 1; k < _ncols - 3; k++) {
                        for (var l = k + 1; l < _ncols - 2; l++) {
                            for (var m = l + 1; m < _ncols - 1; m++) {
                                for (var n = m + 1; n < _ncols; n++) {
                                    total_coms++;
									t6_settings += val_set[i].Count * val_set[j].Count * val_set[k].Count * val_set[l].Count * val_set[m].Count * val_set[n].Count;

									// for each combination in Fail, determine if also in Pass. Report coms in Fail but not in Pass
									for (var rf = 1; rf < _nRowsFaultFile; rf++) {
                                        var in_pass = false; // combination i,j,k,l not yet seen in Pass file
                                        for (var rp = 1; !in_pass && rp < _nRowsNominalFile; rp++) {
                                            //if (test_f[rf][i] == test_p[rp][i] && test_f[rf][j] == test_p[rp][j]//tdm
                                            //&& test_f[rf][k] == test_p[rp][k] && test_f[rf][l] == test_p[rp][l]//tdm
                                            //&& test_f[rf][m] == test_p[rp][m] && test_f[rf][n] == test_p[rp][n])//tdm
                                            if (test_f[rf][i].Equals(test_p[rp][i]) &&
                                                test_f[rf][j].Equals(test_p[rp][j]) &&
                                                test_f[rf][k].Equals(test_p[rp][k]) &&
                                                test_f[rf][l].Equals(test_p[rp][l]) &&
                                                test_f[rf][m].Equals(test_p[rp][m]) &&
                                                test_f[rf][n].Equals(test_p[rp][n])) {
                                                in_pass = true;
                                            }
                                            // in_pass == combination [rf,i,j,k,l] occurs in Pass file also
                                        }
                                        // in_pass && com found in Pass file OR !in_pass and com not in any test of Pass file

                                        if (!in_pass) {
                                            // first make sure not already reported
                                            var flag = false;
                                            if (rf > 0) {
                                                //see if it's in previous row of fault file
                                                for (var i0 = 0; !flag && i0 < rf; i0++) {
                                                    //if (test_f[rf][i] == test_f[i0][i] && test_f[rf][j] == test_f[i0][j]//tdm
                                                    //&& test_f[rf][k] == test_f[i0][k] && test_f[rf][l] == test_f[i0][l]//tdm
                                                    //&& test_f[rf][m] == test_f[i0][m] && test_f[rf][n] == test_f[i0][n]) flag = true; //tdm
                                                    if (test_f[rf][i].Equals(test_f[i0][i]) &&
                                                        test_f[rf][j].Equals(test_f[i0][j]) &&
                                                        test_f[rf][k].Equals(test_f[i0][k]) &&
                                                        test_f[rf][l].Equals(test_f[i0][l]) &&
                                                        test_f[rf][m].Equals(test_f[i0][m]) &&
                                                        test_f[rf][n].Equals(test_f[i0][n])) flag = true;
                                                }
                                            }

                                            if (!flag) {
                                                //sb.AppendFormat(
                                                //    "{0} : {1}, {2}, {3}, {4}, {5}, {6} = {7}, {8}, {9}, {10}, {11}, {12}{13}",
                                                //    rf, i, j, k, l, m, n, test_f[rf][i], test_f[rf][j], test_f[rf][k],
                                                //    test_f[rf][l], test_f[rf][m], test_f[rf][n], Environment.NewLine);

                                                // Fix format to have commas, also show headers like 2-4 way tests
                                                sb.AppendFormat(
                                                    "{0} : {1}, {2}, {3}, {4}, {5}, {6} = {7}, {8}, {9}, {10}, {11}, {12}{13}",
                                                    rf,
                                                    test_f[0][i],
                                                    test_f[0][j],
                                                    test_f[0][k],
                                                    test_f[0][l],
                                                    test_f[0][m],
                                                    test_f[0][n],
                                                    test_f[rf][i],
                                                    test_f[rf][j],
                                                    test_f[rf][k],
                                                    test_f[rf][l],
                                                    test_f[rf][m],
                                                    test_f[rf][n],
                                                    Environment.NewLine);


                                                // Output below takes too long, string concatenation is computationally heavy this many nested loops

                                                //rptBox6way.Text += rf + " : " + i + "," + j + "," + k + "," + l +
                                                //                   "," + m + n + " = "
                                                //                   + test_f[rf][i] + " " + test_f[rf][j] + " " +
                                                //                   test_f[rf][k] + " "
                                                //                   + test_f[rf][l] + " " + test_f[rf][m] + " " +
                                                //                   test_f[rf][n] + " " + Environment.NewLine;
                                                possible_coms++;
                                            }
                                        }
                                        // combination [rf,i,j,k,l,m,n]  either found in Pass file OR not found and reported
                                    }
                                    // for all tests rf in Fail, combination [rf,i,j,k,l,m,n]  either found in Pass file OR not found and reported
                                }
                            }
                        }
                    }
                }
                if (i % 8 == 0) {
                    progress6way.PerformStep();
                }
            }
            rptBox6way.Text = sb.ToString();
            statBox6way.Text = GetSboxComboText(possible_coms,t6_settings);

            //Environment.NewLine + "Possible/total = "
            //    + possible_coms + " / " + total_coms
            //    + " = " + String.Format(" {0:f3}", (float)((float)possible_coms / (float)total_coms));
        }

        private static string GetSboxComboText(int possibleComs, long settings) {
            return string.Format("Combinations = {0}, Settings = {1}", possibleComs,(int)settings);
        }

        private void fBox_TextChanged(object sender, EventArgs e) {
        }

        private void rptBox4way_TextChanged(object sender, EventArgs e) {
        }

        private void AlertUser(string title, string message) {
            MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void WarnUser(string title, string message) {
            MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnTest_Click(object sender, EventArgs e) {
            // Analyze 2-way interactions
            if (chk2WayTest.Checked && _loadCompleteNominalFile) {
                TwoWayTest();
            }

            // Analyze 3-way interactions
            if (chk3WayTest.Checked && _loadCompleteNominalFile) // now do 3-way combinations
            {
                ThreeWayTest();
            }

            // Analyze 4-way interactions
            if (chk4WayTest.Checked && _loadCompleteNominalFile) // now do 4-way combinations
            {
                FourWayTest();
            }

            // Analyze 5-way interactions
            if (chk5WayTest.Checked && _loadCompleteNominalFile) // now do 5-way combinations
            {
                FiveWayTest();
            }

            // Analyze 6-way interactions
            if (chk6WayTest.Checked && _loadCompleteNominalFile) // now do 6-way combinations
            {
                SixWayTest();
            }
        }

        private void chk2WayTest_CheckedChanged(object sender, EventArgs e) {
            SetMultiWayTestTabEnableState(chk2WayTest.Checked, progress2way, statBox2way, rptBox2way);
        }

        private static void SetMultiWayTestTabEnableState(bool status, ProgressBar progressBar, TextBox statBox,
                                                          TextBox rptBox) {
            progressBar.Enabled = status;
            statBox.Enabled = status;
            rptBox.Enabled = status;
        }

        private void chk3WayTest_CheckedChanged(object sender, EventArgs e) {
            SetMultiWayTestTabEnableState(chk3WayTest.Checked, progress3way, statBox3way, rptBox3way);
        }

        private void chk4WayTest_CheckedChanged(object sender, EventArgs e) {
            SetMultiWayTestTabEnableState(chk4WayTest.Checked, progress4way, statBox4way, rptBox4way);
        }

        private void chk5WayTest_CheckedChanged(object sender, EventArgs e) {
            SetMultiWayTestTabEnableState(chk5WayTest.Checked, progress5way, statBox5way, rptBox5way);
        }

        private void chk6WayTest_CheckedChanged(object sender, EventArgs e) {
            SetMultiWayTestTabEnableState(chk6WayTest.Checked, progress6way, statBox6way, rptBox6way);
        }

        private void SetupMultiWayTabStates() {
            SetMultiWayTestTabEnableState(chk2WayTest.Checked, progress2way, statBox2way, rptBox2way);
            SetMultiWayTestTabEnableState(chk3WayTest.Checked, progress3way, statBox3way, rptBox3way);
            SetMultiWayTestTabEnableState(chk4WayTest.Checked, progress4way, statBox4way, rptBox4way);
            SetMultiWayTestTabEnableState(chk5WayTest.Checked, progress5way, statBox5way, rptBox5way);
            SetMultiWayTestTabEnableState(chk6WayTest.Checked, progress6way, statBox6way, rptBox6way);
        }
    }
}