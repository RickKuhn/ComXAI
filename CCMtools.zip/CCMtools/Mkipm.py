## run as python diff <class file> <nominal file>
from __future__ import division

import csv
import sys
import math
import itertools
import datetime
from datetime import timedelta
from collections import Counter
from matplotlib import pyplot as plt
from pylab import *

###############################################
# load csvin file into array
with open(sys.argv[1]) as csvfile:
    xcsvin = list(csv.reader(csvfile))

nrc = len(xcsvin)      # N rows csvin, row count
ncc = len(xcsvin[0])   # N cols csvin, col count

# csvinvals = set containing one of each value in csvinput file
csvinvals = [set() for _ in xrange(ncc)]
for i in range(1,nrc):
   for j in range(ncc):
      csvinvals[j].add(xcsvin[i][j])

# nvals[i] contains number of values of input variable i
# tuples = (nr of vals, index)
# index i saved for re-ordering in ascending order
nvals = range(ncc)
for i in range(ncc):
   nvals[i] = (len(csvinvals[i]), i)
# sorted nvals is ordered by number of values per variable
# tuple contains (nr of values, var index in csvinvals[])   
nvals.sort(key=lambda x: x[0])

# maxnval = nr of variable values for var with largest nr of values
maxnval = max(nvals[ncc-1])

# input model file = 
# row 0 has variable names
# columns in ascending order of nr of var values
f1 = open('ipmodel.csv','w')
# row 0 of f1 contains variable names
for i in range(ncc):
   j = nvals[i][1]
   f1.write("{0}, ".format(xcsvin[0][j]))
f1.write("\n")

# nvals is sorted in ascending order of nr of var values
# columns of ipm contain var values
# nr of rows = max nr of values + 1 for header

for i in range(maxnval):
# take values from each var for columns
   for j in range(ncc):
      k = nvals[j][1]
      if csvinvals[k]:
         f1.write("{0}, ".format(csvinvals[k].pop()))
      else:
         f1.write(", ")
   f1.write("\n")
