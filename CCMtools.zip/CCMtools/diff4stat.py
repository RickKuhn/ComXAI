## run as python diff <class file> <nominal file>
from __future__ import division

import csv
import sys
import math
import itertools
import datetime
from datetime import timedelta
from collections import Counter
from matplotlib import pyplot as plt
from pylab import *
#import argparse

# parser = argparse.ArgumentParser()
# parser.add_argument("-f", "--hdr", help="first line is header ", action="store_true")
# parser.add_argument("<class file>", help="csv file for class")
# parser.add_argument("<non-class file>", help="csv file for non-class")
# args = parser.parse_args()
# if args.hdr:
#     print("header included in csv files")
    

###############################################
# load class file into array
with open(sys.argv[1]) as csvfile:
    xcldata = list(csv.reader(csvfile))

nrc = len(xcldata)      # N rows class, row count
ncc = len(xcldata[0])   # N cols class, col count
xclass = [set() for _ in xrange(ncc)]
ctxclass = [list() for _ in xrange(ncc)]  #store all values for counting later
allclass = [set() for _ in xrange(ncc)]   # store both class and non-class data

for j in range(ncc):
   for i in range(nrc):
      xclass[j].add(xcldata[i][j])
      ctxclass[j].append(xcldata[i][j])
      allclass[j].add(xcldata[i][j])

###############################################
# load nominal, non-class file into array
with open(sys.argv[2]) as csvfile:
    ncldata = list(csv.reader(csvfile))

nrn = len(ncldata)
ncn = len(ncldata[0])
if ncn != ncc: raise IOError("Both files must have same number of parameters")

nonclass = [set() for _ in xrange(ncn)]

for j in range(ncn):
   for i in range(nrn):
      nonclass[j].add(ncldata[i][j])
      allclass[j].add(ncldata[i][j])

###############################################
# compute total possible variable-value settings 
#count of values for each parameter
nvals = range(ncc)   
for i in range(ncc):
   vset = (xclass[i].copy()).union(nonclass[i])
   nvals[i] = len(vset)
   #print("i={0}: {1}".format(i, nvals[i]))
ncoms2 = int(math.factorial(ncc)/(2*math.factorial(ncc-2)))
ncoms3 = int(math.factorial(ncc)/(6*math.factorial(ncc-3)))
ncoms4 = int(math.factorial(ncc)/(24*math.factorial(ncc-4)))
#
totvals1 = sum(nvals[i] for i in range(ncc))
totvals2 = sum(nvals[i]*nvals[j] for i in range(ncc-1) for j in range(i+1,ncc))
totvals3 = sum(nvals[i]*nvals[j]*nvals[k] for i in range(ncc-2) for j in range(i+1,ncc-1) for k in range(j+1,ncc))
totvals4 = sum(nvals[i]*nvals[j]*nvals[k]*nvals[m] for i in range(ncc-3) for j in range(i+1,ncc-2) 
                                                   for k in range(j+1,ncc-1) for m in range(k+1,ncc))

###############################################
# get 1-way set diff class \ non-class
start1way = datetime.datetime.now()
tot1waydiffs = 0
diff1cnts = []
diff1way = [set() for _ in xrange(ncc)]
#ct1way   = [list() for _ in xrange(ncc)] 

for i in range(ncc):
   diff1way[i] = xclass[i].difference(nonclass[i])
   tot1waydiffs += len(diff1way[i])
   # print(diff1way[i])
   # print(ctxclass[i])
   # print(ctxclass.count(i))
sys.stderr.write("1way diffs done {0}\n".format(datetime.datetime.now()))

###############################################
# output 1way diffs
f1 = open('diff1way.csv','w')
f1.write("N,  i, val\n")
for i in range(ncc):
   if len(diff1way[i]) > 0:
      #print("P", i, diff1way[i])
      for xtup in diff1way[i]:
         #print("       1-way {0} => {1}".format( i, xtup))
         f1.write("{2}/{3}  {0} = {1}\n".format( i, xtup, ctxclass[i].count(xtup),nrc))
         diff1cnts.append((ctxclass[i].count(xtup),xtup))
         # print(xtup)
         # print(ctxclass[i].count(xtup))
#print(diff1cnts)
#################################################################################################
#################################################################################################
# set up 2way difference sets
start2way = datetime.datetime.now()
diff2way = [list() for _ in xrange(ncc-1)]
diff2cnts = []
for i in range(ncc-1):
   diff2way[i] = [set() for _ in xrange(ncc)]
   
###############################################
# load 2way combinations for xclass data,
xclass2w = [list() for _ in xrange(ncc-1)]
ctxclass2w = [list() for _ in xrange(ncc-1)]
allclass2w = [list() for _ in xrange(ncc-1)]

for i in range(ncc-1):
   xclass2w[i] = [set() for _ in xrange(ncc)]
   ctxclass2w[i] = [list() for _ in xrange(ncc)]
   allclass2w[i] = [set() for _ in xrange(ncc)]

for r in range(nrc):
   for i in range(ncc-1):
      for j in range(i+1,ncc):
         #print("add",r,i,j)
         xclass2w[i][j].add( (xcldata[r][i],xcldata[r][j]) )
         ctxclass2w[i][j].append((xcldata[r][i],xcldata[r][j]))
         # print(r,i,j,(xcldata[r][i],xcldata[r][j]))
         # print(r,i,j,ctxclass2w[i][j])
         allclass2w[i][j].add( (xcldata[r][i],xcldata[r][j]) )

###############################################
# load 2way combinations for nonclass data
nclass2w = [list() for _ in xrange(ncc-1)]
for i in range(ncc-1):
   nclass2w[i] = [set() for _ in xrange(ncc)]
   #xclass2w[i] = [set() for _ in xrange(i+1,ncc)]

for r in range(nrn):
   for i in range(ncc-1):
      for j in range(i+1,ncc):
         #print("add",r,i,j)
         nclass2w[i][j].add( (ncldata[r][i],ncldata[r][j]) )
         allclass2w[i][j].add( (ncldata[r][i],ncldata[r][j]) )

###############################################
# get 2way set diff class \ nonclass
for i in range(ncc-1):
   for j in range(i+1,ncc):
      diff2way[i][j] = xclass2w[i][j].difference(nclass2w[i][j])
sys.stderr.write("2way diffs done {0}\n".format(datetime.datetime.now()))
# for i in range(ncc-1):
#       for j in range(i+1,ncc):
#          print(ctxclass2w[i][j])

###############################################
# output 2way diffs
tot2waydiffs = 0
f2 = open('diff2way.csv','w')
f2.write("i,j,  ival,jval\n")
for i in range(ncc-1):
   for j in range(i+1,ncc):
      if len(diff2way[i][j]) > 0:   
         # print("2way ")
         # for tup1 in diff2way[i][j]:
         #    print(i,j, "=", tup1)
         tot2waydiffs += len(diff2way[i][j])
         for xtup in diff2way[i][j]:
            f2.write("{0},{1},  {2},{3}\n".format( i,j, xtup[0], xtup[1]))

#############################################
# remove 2-tuples that contain a parm val in diff1way
totfilt2way = 0
f2f = open('filter2way.csv', 'w')
f2.write("i,j,  ival,jval\n")

filt2way = [list() for _ in xrange(ncc-1)]
for i in range(ncc-1):
   filt2way[i] = [set() for _ in xrange(ncc)]

for i in range(ncc-1):
   for j in range(i+1,ncc):
      for xtup in diff2way[i][j]:
         if xtup[0] not in diff1way[i] and xtup[1] not in diff1way[j]:
            filt2way[i][j].add(xtup)
            totfilt2way += 1
            #print("filtered 2-way {0},{1} => {2}".format( i,j, xtup))
            diff2cnts.append((ctxclass2w[i][j].count(xtup),xtup))
            f2f.write("{4}/{5}:  {0},{1} = {2},{3}\n".format(i,j,xtup[0],xtup[1],
                                                   ((ctxclass2w[i][j]).count(xtup)),nrc))

#################################################################################################
#################################################################################################
# set up 3way difference sets
start3way = datetime.datetime.now()
diff3way = [[list() for _ in xrange(ncc)]  for _ in xrange(ncc)]
diff3cnts = []
for i in range(ncc-2):
   for j in range(i+1,ncc-1):
      diff3way[i][j] = [set() for _ in xrange(ncc)]

###############################################
# load 3-way combinations for xclass data
xclass3w = [[list() for _ in xrange(ncc)]  for _ in xrange(ncc)]
ctxclass3w = [[list() for _ in xrange(ncc)]  for _ in xrange(ncc)]
allclass3w = [[list() for _ in xrange(ncc)]  for _ in xrange(ncc)]

for i in range(ncc-2):
   for j in range(i+1,ncc-1):
      xclass3w[i][j] = [set() for _ in xrange(ncc)]
      ctxclass3w[i][j] = [list() for _ in xrange(ncc)]
      allclass3w[i][j] = [set() for _ in xrange(ncc)]

for r in range(nrc):
   for i in range(ncc-2):
      for j in range(i+1,ncc-1):
         for k in range(j+1,ncc):
            #print("add",r,i,j)
            xclass3w[i][j][k].add( (xcldata[r][i],xcldata[r][j],xcldata[r][k]) )
            ctxclass3w[i][j][k].append( (xcldata[r][i],xcldata[r][j],xcldata[r][k]) )
            allclass3w[i][j][k].add( (xcldata[r][i],xcldata[r][j],xcldata[r][k]) )

###############################################
# load 3-way combinations for nclass data
nclass3w = [[list() for _ in xrange(ncc)]  for _ in xrange(ncc)]
for i in range(ncc-2):
   for j in range(i+1,ncc-1):
      nclass3w[i][j] = [set() for _ in xrange(ncc)]

for r in range(nrn):
   for i in range(ncc-2):
      for j in range(i+1,ncc-1):
         for k in range(j+1,ncc):
            #print("add",r,i,j)
            nclass3w[i][j][k].add( (ncldata[r][i],ncldata[r][j],ncldata[r][k]) )
            allclass3w[i][j][k].add( (ncldata[r][i],ncldata[r][j],ncldata[r][k]) )

###############################################
# get 3way set diff class \ nonclass
for i in range(ncc-2):
   for j in range(i+1,ncc-1):
      for k in range(j+1,ncc):
         diff3way[i][j][k] = xclass3w[i][j][k].difference(nclass3w[i][j][k])
sys.stderr.write("3way diffs done {0}\n".format(datetime.datetime.now()))

###############################################
# output 3way diffs
tot3waydiffs = 0
f3 = open('diff3way.csv','w')
f3.write("i,j,k,  ival,jval,kval\n")
for i in range(ncc-2):
   for j in range(i+1,ncc-1):
      for k in range(j+1,ncc):
         if len(diff3way[i][j][k]) > 0:   
            # print("3way ", i,j,k)
            # for tup1 in diff3way[i][j][k]:
            #    print(tup1)
            tot3waydiffs += len(diff3way[i][j][k])
            for xtup in diff3way[i][j][k]:
               f3.write("{0},{1},{2} = {3},{4},{5}\n".format(i,j,k, xtup[0],xtup[1],xtup[2]))

#############################################
# remove 3-tuples that contain a parm val in diff1way or diff2way
totfilt3way = 0
f3f = open('filter3way.csv','w')
f3f.write("i,j,k,  ival,jval,kval\n")
filt3way = [[list() for _ in xrange(ncc)]  for _ in xrange(ncc)]
for i in range(ncc-2):
   for j in range(i+1,ncc-1):
      filt3way[i][j] = [set() for _ in xrange(ncc)]

for i in range(ncc-2):
   for j in range(i+1,ncc-1):
      for k in range(j+1,ncc):
         for xtup in diff3way[i][j][k]:
            if (xtup[0] not in diff1way[i] and xtup[1] not in diff1way[j] and xtup[2] not in diff1way[k] and 
                (xtup[0],xtup[1]) not in diff2way[i][j] and (xtup[0],xtup[2]) not in diff2way[i][k] and 
                (xtup[1],xtup[2]) not in diff2way[j][k] ):
               filt3way[i][j][k].add(xtup)
               totfilt3way += 1
               #print("filtered 3-way {0},{1},{2} => {3}".format( i,j,k, xtup))
               #for xtup in filt3way[i][j][k]:
               diff3cnts.append((ctxclass3w[i][j][k].count(xtup),xtup))
               f3f.write("{6}/{7}  {0},{1},{2} = {3},{4},{5}\n".format(i,j,k, xtup[0],xtup[1],xtup[2],
                                                                  ((ctxclass3w[i][j][k]).count(xtup)),nrc))

##############################################################################################################
##############################################################################################################
# set up 4way difference sets
# start4way = datetime.datetime.now()
# d1 = (start2way-start1way)
# d2 = (start3way-start2way)
#ff1 = d2/d1
#est4waytime = d2*ff1
# print("d1",d1)
# print("d2",d2)

diff4way = [[[list() for _ in xrange(ncc)]  for _ in xrange(ncc)] for _ in xrange(ncc)]
diff4cnts = []
for i in range(ncc-3):
   for j in range(i+1,ncc-2):
      for k in range(j+1,ncc-1):
         diff4way[i][j][k] = [set() for _ in xrange(ncc)]

###############################################
# load 4-way combinations for xclass data
xclass4w = [[[list() for _ in xrange(ncc)]  for _ in xrange(ncc)] for _ in xrange(ncc)]
ctxclass4w = [[[list() for _ in xrange(ncc)]  for _ in xrange(ncc)] for _ in xrange(ncc)]
allclass4w = [[[list() for _ in xrange(ncc)]  for _ in xrange(ncc)] for _ in xrange(ncc)]

for i in range(ncc-3):
   for j in range(i+1,ncc-2):
      for k in range(j+1,ncc-1):
         xclass4w[i][j][k] = [set() for _ in xrange(ncc)]
         ctxclass4w[i][j][k] = [list() for _ in xrange(ncc)]
         allclass4w[i][j][k] = [set() for _ in xrange(ncc)]

for r in range(nrc):
   for i in range(ncc-3):
      for j in range(i+1,ncc-2):
         for k in range(j+1,ncc-1):
            for m in range(k+1,ncc):
               xclass4w[i][j][k][m].add( (xcldata[r][i],xcldata[r][j],xcldata[r][k],xcldata[r][m]) )
               ctxclass4w[i][j][k][m].append( (xcldata[r][i],xcldata[r][j],xcldata[r][k],xcldata[r][m]) )
               allclass4w[i][j][k][m].add( (xcldata[r][i],xcldata[r][j],xcldata[r][k],xcldata[r][m]) )

###############################################
# load 4-way combinations for nonclass data
nclass4w = [[[list() for _ in xrange(ncc)]  for _ in xrange(ncc)] for _ in xrange(ncc)]
for i in range(ncc-3):
   for j in range(i+1,ncc-2):
      for k in range(j+1,ncc-1):
         nclass4w[i][j][k] = [set() for _ in xrange(ncc)]

for r in range(nrn):
   for i in range(ncc-3):
      for j in range(i+1,ncc-2):
         for k in range(j+1,ncc-1):
            for m in range(k+1,ncc):
               nclass4w[i][j][k][m].add( (ncldata[r][i],ncldata[r][j],ncldata[r][k],ncldata[r][m]) )
               allclass4w[i][j][k][m].add( (ncldata[r][i],ncldata[r][j],ncldata[r][k],ncldata[r][m]) )

###############################################
# get 4way set diff class \\ nonclass
for i in range(ncc-3):
   for j in range(i+1,ncc-2):
      for k in range(j+1,ncc-1):
         for m in range(k+1,ncc):
            diff4way[i][j][k][m] = xclass4w[i][j][k][m].difference(nclass4w[i][j][k][m])
sys.stderr.write("4way diffs done {0}\n".format(datetime.datetime.now()))

###############################################
# output 4way diffs
tot4waydiffs = 0
f4 = open('diff4way.csv','w')
f4.write("i,j,k,m,  ival,jval,kval,mval\n")
for i in range(ncc-3):
   for j in range(i+1,ncc-2):
      for k in range(j+1,ncc-1):
         for m in range(k+1,ncc):
            if len(diff4way[i][j][k][m]) > 0:   
               # print("4way ", i,j,k,m)
               # for tup1 in diff4way[i][j][k][m]:
               #    print(tup1)
               tot4waydiffs += len(diff4way[i][j][k][m])
               for xtup in diff4way[i][j][k][m]:
                  f4.write("{0},{1},{2},{3},  {4},{5},{6},{7}\n".format(i,j,k,m, xtup[0],xtup[1],xtup[2],xtup[3]))

#############################################
# remove 4-tuples that contain a parm val in diff1way or diff2way or diff3way
totfilt4way = 0
f4f = open('filter4way.csv','w')
f4f.write("i,j,k,m,  ival,jval,kval,mval\n")
filt4way = [[[list() for _ in xrange(ncc)]  for _ in xrange(ncc)] for _ in xrange(ncc)]
for i in range(ncc-3):
   for j in range(i+1,ncc-2):
      for k in range(j+1,ncc-1):
         filt4way[i][j][k] = [set() for _ in xrange(ncc)]

for i in range(ncc-3):
   for j in range(i+1,ncc-2):
      for k in range(j+1,ncc-1):
         for m in range(k+1,ncc):
            for xtup in diff4way[i][j][k][m]:
               if ( xtup[0] not in diff1way[i] and xtup[1] not in diff1way[j] and 
                    xtup[2] not in diff1way[k] and xtup[3] not in diff1way[m] and
                   (xtup[0],xtup[1]) not in diff2way[i][j] and (xtup[0],xtup[2]) not in diff2way[i][k] and 
                   (xtup[0],xtup[3]) not in diff2way[i][m] and (xtup[1],xtup[2]) not in diff2way[j][k] and 
                   (xtup[1],xtup[3]) not in diff2way[j][m] and (xtup[2],xtup[3]) not in diff2way[k][m] and 
                   (xtup[0],xtup[1],xtup[2] not in diff3way[i][j][k]) and 
                   (xtup[0],xtup[1],xtup[3] not in diff3way[i][j][m]) and 
                   (xtup[0],xtup[2],xtup[3] not in diff3way[i][k][m]) and 
                   (xtup[1],xtup[2],xtup[3] not in diff3way[j][k][m])    ):
                  filt4way[i][j][k][m].add(xtup)
                  totfilt4way += 1
                  #print("filtered 4-way {0},{1},{2},{3} => {4}".format( i,j,k,m, xtup))
                  #for xtup in diff4way[i][j][k][m]:
                  diff4cnts.append((ctxclass4w[i][j][k][m].count(xtup),xtup))
                  f4f.write("{8}/{9}  {0},{1},{2},{3},  {4},{5},{6},{7}\n".format(i,j,k,m, xtup[0],xtup[1],xtup[2],xtup[3],
                                                                        ((ctxclass4w[i][j][k][m]).count(xtup)),nrc))

#############################################
# output report
n_allclass2w = sum(len(allclass2w[i][j]) for i in range(ncc-1) for j in range(i+1,ncc))
n_allclass3w = sum(len(allclass3w[i][j][k]) for i in range(ncc-2) for j in range(i+1,ncc-1) for k in range(j+1,ncc))
n_allclass4w = sum(len(allclass4w[i][j][k][m]) for i in range(ncc-3) for j in range(i+1,ncc-2) 
                                                for k in range(j+1,ncc-1) for m in range(k+1,ncc))


print("_"*70)
#print("   ")
print("  t-WAY COMBINATIONS: CLASS \ NON-CLASS  ")
print(" ")
print("Class = {0}       Non-class = {1}".format(sys.argv[1], sys.argv[2]))
print(" ")
print("Nvars: {:>5,}      Nrows class: {:>7,}       Nrows non-class:  {:>7,}".format(ncc,nrc,nrn))
print("_"*70)
print("t| total diffs|   filtered |filt/max|       max |   cov      |cov/max|")
print("1|{:>12,}|{:>12,}| {:>.4f}|{:>12,}|{:>12,}| {:>.4f}|".format(tot1waydiffs,tot1waydiffs,(tot1waydiffs/totvals1),
                                                            totvals1,totvals1,1))
print("2|{:>12,}|{:>12,}| {:>.4f}|{:>12,}|{:>12,}| {:>.4f}|".format(tot2waydiffs,totfilt2way,(totfilt2way/totvals2),
                                                            totvals2,n_allclass2w,(n_allclass2w/totvals2)))
print("3|{:>12,}|{:>12,}| {:>.4f}|{:>12,}|{:>12,}| {:>.4f}|".format(tot3waydiffs,totfilt3way,(totfilt3way/totvals3),
                                                            totvals3,n_allclass3w,(n_allclass3w/totvals3)))
print("4|{:>12,}|{:>12,}| {:>.4f}|{:>12,}|{:>12,}| {:>.4f}|".format(tot4waydiffs,totfilt4way,(totfilt4way/totvals4),
                                                            totvals4,n_allclass4w,(n_allclass4w/totvals4)))

print("_"*70)
if len(diff1cnts) > 0:
   max1 = max(count for (count, tup) in diff1cnts)
   examp1 = itertools.islice(filter(lambda x: x[0] == max1, diff1cnts), 1)
   print("Rows with max 1-way diffs:  {:>12}/{:<12} = {:>.4f}".format(max1,nrc,(max1/nrc)))

if len(diff2cnts) > 0:
   max2 = max(count for (count, tup) in diff2cnts)
   examp2 = itertools.islice(filter(lambda x: x[0] == max2, diff2cnts), 1)
   print("Rows with max 2-way diffs:  {:>12}/{:<12} = {:>.4f}".format( max2,nrc,(max2/nrc)))
   
if len(diff3cnts) > 0:
   max3 = max(count for (count, tup) in diff3cnts)
   examp3 = itertools.islice(filter(lambda x: x[0] == max3, diff3cnts), 1)
   # print(list(examp3))
   print("Rows with max 3-way diffs:  {:>12}/{:<12} = {:>.4f}".format( max3,nrc,(max3/nrc)))
      
if len(diff4cnts) > 0:
   max4 = max(count for (count, tup) in diff4cnts)
   examp4 = itertools.islice(filter(lambda x: x[0] == max4, diff4cnts), 1)
   print("Rows with max 4-way diffs:  {:>12}/{:<12} = {:>.4f}".format( max4,nrc,(max4/nrc)))
print("_"*70)

########################################################################
## Class coverage plot
# 2way coverage plot
yvals2 = []
for i in range(ncc-1):
   for j in range(i+1,ncc):
      yvals2.append(len(xclass2w[i][j])/(nvals[i]*nvals[j]))
xvals2 = range(ncoms2)
## Coverage as in CCM;  completeness

plt.figure(figsize=(12,12))

subplot(221)
plt.title("Class com coverage")
plt.ylim(0,1)
plt.xlim(0,1)
yvals2.sort()
sfx2 = ncoms2-1
yvals2.reverse()

X2 = array(xvals2)
Y2 = array(yvals2)
Xd2 = X2/sfx2
########################################################################
# 3way coverage plot
yvals3 = []
for i in range(ncc-2):
   for j in range(i+1,ncc-1):
      for k in range(j+1,ncc):
         yvals3.append(len(xclass3w[i][j][k] )/(nvals[i]*nvals[j]*nvals[k]))
xvals3 = range(ncoms3)
## Coverage as in CCM;  completeness

yvals3.sort()
sfx3 = ncoms3-1
yvals3.reverse()

X3 = array(xvals3)
Y3 = array(yvals3)
Xd3 = X3/sfx3
########################################################################
# 4way coverage plot
yvals4 = []
for i in range(ncc-3):
   for j in range(i+1,ncc-2):
      for k in range(j+1,ncc-1):
         for m in range(k+1,ncc):
            yvals4.append(len(xclass4w[i][j][k][m] )/(nvals[i]*nvals[j]*nvals[k]*nvals[m]))
xvals4 = range(ncoms4)
## Coverage as in CCM;  completeness

yvals4.sort()
sfx4 = ncoms4-1
yvals4.reverse()

X4 = array(xvals4)
Y4 = array(yvals4)
Xd4 = X4/sfx4
########################################################################
# display plots
plt.figaspect(1.)
plt.plot(Xd2,Y2,color="red", label="2-way")
plt.plot(Xd3,Y3,color="blue", label="3-way")
plt.plot(Xd4,Y4,color="green", label="4-way")

plt.grid()      
#plt.show()
########################################################################
##   Non-class coverage plot 
yvals2 = []
for i in range(ncc-1):
   for j in range(i+1,ncc):
      yvals2.append(len(nclass2w[i][j] )/(nvals[i]*nvals[j]))
xvals2 = range(ncoms2)
## Coverage as in CCM;  completeness
subplot(222)
plt.title("Non-class coverage")
plt.ylim(0,1)
plt.xlim(0,1)
yvals2.sort()
sfx2 = ncoms2-1
yvals2.reverse()

X2 = array(xvals2)
Y2 = array(yvals2)
Xd2 = X2/sfx2
#Yd2 = Y2/sfy2
########################################################################
# 3way coverage plot
yvals3 = []
for i in range(ncc-2):
   for j in range(i+1,ncc-1):
      for k in range(j+1,ncc):
         yvals3.append(len(nclass3w[i][j][k] )/(nvals[i]*nvals[j]*nvals[k]))
xvals3 = range(ncoms3)
## Coverage as in CCM;  completeness

yvals3.sort()
sfx3 = ncoms3-1
yvals3.reverse()

X3 = array(xvals3)
Y3 = array(yvals3)
Xd3 = X3/sfx3
########################################################################
# 4way coverage plot
yvals4 = []
for i in range(ncc-3):
   for j in range(i+1,ncc-2):
      for k in range(j+1,ncc-1):
         for m in range(k+1,ncc):
            yvals4.append(len(nclass4w[i][j][k][m] )/(nvals[i]*nvals[j]*nvals[k]*nvals[m]))
xvals4 = range(ncoms4)

yvals4.sort()
sfx4 = ncoms4-1
yvals4.reverse()

X4 = array(xvals4)
Y4 = array(yvals4)
Xd4 = X4/sfx4
#Yd4 = Y4/sfy4
########################################################################

plt.plot(Xd2,Y2,color="red", label="2-way")
plt.plot(Xd3,Y3,color="blue", label="3-way")
plt.plot(Xd4,Y4,color="green", label="4-way")
plt.grid()      

########################################################################
##   Full data set coverage plot 
yvals2 = []
for i in range(ncc-1):
   for j in range(i+1,ncc):
      yvals2.append(len(allclass2w[i][j] )/(nvals[i]*nvals[j]))
xvals2 = range(ncoms2)
## Coverage as in CCM;  completeness
subplot(223)
plt.title("Full data set coverage")
plt.ylim(0,1)
plt.xlim(0,1)
yvals2.sort()
sfx2 = ncoms2-1
yvals2.reverse()

X2 = array(xvals2)
Y2 = array(yvals2)
Xd2 = X2/sfx2
#Yd2 = Y2/sfy2
########################################################################
# 3way coverage plot
yvals3 = []
for i in range(ncc-2):
   for j in range(i+1,ncc-1):
      for k in range(j+1,ncc):
         yvals3.append(len(allclass3w[i][j][k] )/(nvals[i]*nvals[j]*nvals[k]))
xvals3 = range(ncoms3)
## Coverage as in CCM;  completeness

yvals3.sort()
sfx3 = ncoms3-1
yvals3.reverse()

X3 = array(xvals3)
Y3 = array(yvals3)
Xd3 = X3/sfx3
########################################################################
# 4way coverage plot
yvals4 = []
for i in range(ncc-3):
   for j in range(i+1,ncc-2):
      for k in range(j+1,ncc-1):
         for m in range(k+1,ncc):
            yvals4.append(len(allclass4w[i][j][k][m] )/(nvals[i]*nvals[j]*nvals[k]*nvals[m]))
xvals4 = range(ncoms4)

yvals4.sort()
sfx4 = ncoms4-1
yvals4.reverse()

X4 = array(xvals4)
Y4 = array(yvals4)
Xd4 = X4/sfx4
#Yd4 = Y4/sfy4
########################################################################

plt.plot(Xd2,Y2,color="red", label="2-way")
plt.plot(Xd3,Y3,color="blue", label="3-way")
plt.plot(Xd4,Y4,color="green", label="4-way")

plt.grid()      

###############################
##  Display all graphs
plt.show()
