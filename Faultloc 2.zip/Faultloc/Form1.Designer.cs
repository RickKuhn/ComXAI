﻿namespace Faultloc
{
    partial class Faultloc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoadFaultFile = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.txtFaultContents = new System.Windows.Forms.TextBox();
            this.btnLoadNominalFile = new System.Windows.Forms.Button();
            this.rptBox2way = new System.Windows.Forms.TextBox();
            this.txtNominalInfo = new System.Windows.Forms.TextBox();
            this.rptBox3way = new System.Windows.Forms.TextBox();
            this.rptBox4way = new System.Windows.Forms.TextBox();
            this.chk2WayTest = new System.Windows.Forms.CheckBox();
            this.chk3WayTest = new System.Windows.Forms.CheckBox();
            this.chk4WayTest = new System.Windows.Forms.CheckBox();
            this.txtFaultInfo = new System.Windows.Forms.TextBox();
            this.statBox2way = new System.Windows.Forms.TextBox();
            this.statBox4way = new System.Windows.Forms.TextBox();
            this.statBox3way = new System.Windows.Forms.TextBox();
            this.progress2way = new System.Windows.Forms.ProgressBar();
            this.progress3way = new System.Windows.Forms.ProgressBar();
            this.progress4way = new System.Windows.Forms.ProgressBar();
            this.chk5WayTest = new System.Windows.Forms.CheckBox();
            this.progress5way = new System.Windows.Forms.ProgressBar();
            this.statBox5way = new System.Windows.Forms.TextBox();
            this.rptBox5way = new System.Windows.Forms.TextBox();
            this.chk6WayTest = new System.Windows.Forms.CheckBox();
            this.progress6way = new System.Windows.Forms.ProgressBar();
            this.statBox6way = new System.Windows.Forms.TextBox();
            this.rptBox6way = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.grpFileInfo = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnTest = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.grpFileInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnLoadFaultFile
            // 
            this.btnLoadFaultFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLoadFaultFile.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnLoadFaultFile.Location = new System.Drawing.Point(1266, 19);
            this.btnLoadFaultFile.Name = "btnLoadFaultFile";
            this.btnLoadFaultFile.Size = new System.Drawing.Size(120, 21);
            this.btnLoadFaultFile.TabIndex = 0;
            this.btnLoadFaultFile.Text = "Load Class";
            this.btnLoadFaultFile.UseVisualStyleBackColor = false;
            this.btnLoadFaultFile.Click += new System.EventHandler(this.BtnLoadFaultFile_Click);
            // 
            // txtFaultContents
            // 
            this.txtFaultContents.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFaultContents.Location = new System.Drawing.Point(109, 73);
            this.txtFaultContents.Multiline = true;
            this.txtFaultContents.Name = "txtFaultContents";
            this.txtFaultContents.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtFaultContents.Size = new System.Drawing.Size(1277, 100);
            this.txtFaultContents.TabIndex = 1;
            this.txtFaultContents.WordWrap = false;
            this.txtFaultContents.TextChanged += new System.EventHandler(this.fBox_TextChanged);
            // 
            // btnLoadNominalFile
            // 
            this.btnLoadNominalFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLoadNominalFile.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnLoadNominalFile.Location = new System.Drawing.Point(1266, 46);
            this.btnLoadNominalFile.Name = "btnLoadNominalFile";
            this.btnLoadNominalFile.Size = new System.Drawing.Size(120, 21);
            this.btnLoadNominalFile.TabIndex = 3;
            this.btnLoadNominalFile.Text = "Load Nominal";
            this.btnLoadNominalFile.UseVisualStyleBackColor = false;
            this.btnLoadNominalFile.Click += new System.EventHandler(this.nomButton_Click);
            // 
            // rptBox2way
            // 
            this.rptBox2way.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rptBox2way.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rptBox2way.Location = new System.Drawing.Point(6, 59);
            this.rptBox2way.Multiline = true;
            this.rptBox2way.Name = "rptBox2way";
            this.rptBox2way.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.rptBox2way.Size = new System.Drawing.Size(1372, 408);
            this.rptBox2way.TabIndex = 4;
            this.rptBox2way.WordWrap = false;
            // 
            // txtNominalInfo
            // 
            this.txtNominalInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNominalInfo.Location = new System.Drawing.Point(109, 46);
            this.txtNominalInfo.Name = "txtNominalInfo";
            this.txtNominalInfo.Size = new System.Drawing.Size(1151, 20);
            this.txtNominalInfo.TabIndex = 7;
            // 
            // rptBox3way
            // 
            this.rptBox3way.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rptBox3way.Font = new System.Drawing.Font("Courier New", 11.25F);
            this.rptBox3way.Location = new System.Drawing.Point(6, 59);
            this.rptBox3way.Multiline = true;
            this.rptBox3way.Name = "rptBox3way";
            this.rptBox3way.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.rptBox3way.Size = new System.Drawing.Size(1372, 408);
            this.rptBox3way.TabIndex = 8;
            this.rptBox3way.WordWrap = false;
            // 
            // rptBox4way
            // 
            this.rptBox4way.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rptBox4way.Font = new System.Drawing.Font("Courier New", 11.25F);
            this.rptBox4way.Location = new System.Drawing.Point(6, 59);
            this.rptBox4way.Multiline = true;
            this.rptBox4way.Name = "rptBox4way";
            this.rptBox4way.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.rptBox4way.Size = new System.Drawing.Size(1372, 408);
            this.rptBox4way.TabIndex = 9;
            this.rptBox4way.WordWrap = false;
            this.rptBox4way.TextChanged += new System.EventHandler(this.rptBox4way_TextChanged);
            // 
            // chk2WayTest
            // 
            this.chk2WayTest.AutoSize = true;
            this.chk2WayTest.Checked = true;
            this.chk2WayTest.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chk2WayTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk2WayTest.Location = new System.Drawing.Point(6, 6);
            this.chk2WayTest.Name = "chk2WayTest";
            this.chk2WayTest.Size = new System.Drawing.Size(72, 17);
            this.chk2WayTest.TabIndex = 12;
            this.chk2WayTest.Text = "Enabled";
            this.chk2WayTest.UseVisualStyleBackColor = true;
            this.chk2WayTest.CheckedChanged += new System.EventHandler(this.chk2WayTest_CheckedChanged);
            // 
            // chk3WayTest
            // 
            this.chk3WayTest.AutoSize = true;
            this.chk3WayTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk3WayTest.Location = new System.Drawing.Point(6, 6);
            this.chk3WayTest.Name = "chk3WayTest";
            this.chk3WayTest.Size = new System.Drawing.Size(72, 17);
            this.chk3WayTest.TabIndex = 13;
            this.chk3WayTest.Text = "Enabled";
            this.chk3WayTest.UseVisualStyleBackColor = true;
            this.chk3WayTest.CheckedChanged += new System.EventHandler(this.chk3WayTest_CheckedChanged);
            // 
            // chk4WayTest
            // 
            this.chk4WayTest.AutoSize = true;
            this.chk4WayTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk4WayTest.Location = new System.Drawing.Point(6, 6);
            this.chk4WayTest.Name = "chk4WayTest";
            this.chk4WayTest.Size = new System.Drawing.Size(72, 17);
            this.chk4WayTest.TabIndex = 14;
            this.chk4WayTest.Text = "Enabled";
            this.chk4WayTest.UseVisualStyleBackColor = true;
            this.chk4WayTest.CheckedChanged += new System.EventHandler(this.chk4WayTest_CheckedChanged);
            // 
            // txtFaultInfo
            // 
            this.txtFaultInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFaultInfo.Location = new System.Drawing.Point(109, 19);
            this.txtFaultInfo.Name = "txtFaultInfo";
            this.txtFaultInfo.Size = new System.Drawing.Size(1151, 20);
            this.txtFaultInfo.TabIndex = 15;
            // 
            // statBox2way
            // 
            this.statBox2way.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.statBox2way.Font = new System.Drawing.Font("Courier New", 11.25F);
            this.statBox2way.Location = new System.Drawing.Point(6, 29);
            this.statBox2way.Name = "statBox2way";
            this.statBox2way.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.statBox2way.Size = new System.Drawing.Size(1372, 24);
            this.statBox2way.TabIndex = 5;
            // 
            // statBox4way
            // 
            this.statBox4way.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.statBox4way.Font = new System.Drawing.Font("Courier New", 11.25F);
            this.statBox4way.Location = new System.Drawing.Point(6, 29);
            this.statBox4way.Name = "statBox4way";
            this.statBox4way.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.statBox4way.Size = new System.Drawing.Size(1372, 24);
            this.statBox4way.TabIndex = 11;
            // 
            // statBox3way
            // 
            this.statBox3way.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.statBox3way.Font = new System.Drawing.Font("Courier New", 11.25F);
            this.statBox3way.Location = new System.Drawing.Point(6, 29);
            this.statBox3way.Name = "statBox3way";
            this.statBox3way.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.statBox3way.Size = new System.Drawing.Size(1372, 24);
            this.statBox3way.TabIndex = 10;
            // 
            // progress2way
            // 
            this.progress2way.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progress2way.Location = new System.Drawing.Point(84, 6);
            this.progress2way.Name = "progress2way";
            this.progress2way.Size = new System.Drawing.Size(1294, 16);
            this.progress2way.TabIndex = 17;
            // 
            // progress3way
            // 
            this.progress3way.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progress3way.Location = new System.Drawing.Point(84, 6);
            this.progress3way.Name = "progress3way";
            this.progress3way.Size = new System.Drawing.Size(1294, 16);
            this.progress3way.TabIndex = 18;
            // 
            // progress4way
            // 
            this.progress4way.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progress4way.Location = new System.Drawing.Point(84, 6);
            this.progress4way.Name = "progress4way";
            this.progress4way.Size = new System.Drawing.Size(1294, 16);
            this.progress4way.TabIndex = 19;
            // 
            // chk5WayTest
            // 
            this.chk5WayTest.AutoSize = true;
            this.chk5WayTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk5WayTest.Location = new System.Drawing.Point(6, 6);
            this.chk5WayTest.Name = "chk5WayTest";
            this.chk5WayTest.Size = new System.Drawing.Size(72, 17);
            this.chk5WayTest.TabIndex = 20;
            this.chk5WayTest.Text = "Enabled";
            this.chk5WayTest.UseVisualStyleBackColor = true;
            this.chk5WayTest.CheckedChanged += new System.EventHandler(this.chk5WayTest_CheckedChanged);
            // 
            // progress5way
            // 
            this.progress5way.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progress5way.Location = new System.Drawing.Point(84, 6);
            this.progress5way.Name = "progress5way";
            this.progress5way.Size = new System.Drawing.Size(1294, 16);
            this.progress5way.TabIndex = 21;
            // 
            // statBox5way
            // 
            this.statBox5way.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.statBox5way.Font = new System.Drawing.Font("Courier New", 11.25F);
            this.statBox5way.Location = new System.Drawing.Point(6, 29);
            this.statBox5way.Name = "statBox5way";
            this.statBox5way.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.statBox5way.Size = new System.Drawing.Size(1372, 24);
            this.statBox5way.TabIndex = 22;
            // 
            // rptBox5way
            // 
            this.rptBox5way.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rptBox5way.Font = new System.Drawing.Font("Courier New", 11.25F);
            this.rptBox5way.Location = new System.Drawing.Point(6, 59);
            this.rptBox5way.Multiline = true;
            this.rptBox5way.Name = "rptBox5way";
            this.rptBox5way.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.rptBox5way.Size = new System.Drawing.Size(1372, 408);
            this.rptBox5way.TabIndex = 23;
            this.rptBox5way.WordWrap = false;
            // 
            // chk6WayTest
            // 
            this.chk6WayTest.AutoSize = true;
            this.chk6WayTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk6WayTest.Location = new System.Drawing.Point(6, 6);
            this.chk6WayTest.Name = "chk6WayTest";
            this.chk6WayTest.Size = new System.Drawing.Size(72, 17);
            this.chk6WayTest.TabIndex = 24;
            this.chk6WayTest.Text = "Enabled";
            this.chk6WayTest.UseVisualStyleBackColor = true;
            this.chk6WayTest.CheckedChanged += new System.EventHandler(this.chk6WayTest_CheckedChanged);
            // 
            // progress6way
            // 
            this.progress6way.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progress6way.Location = new System.Drawing.Point(84, 6);
            this.progress6way.Name = "progress6way";
            this.progress6way.Size = new System.Drawing.Size(1294, 16);
            this.progress6way.TabIndex = 25;
            // 
            // statBox6way
            // 
            this.statBox6way.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.statBox6way.Font = new System.Drawing.Font("Courier New", 11.25F);
            this.statBox6way.Location = new System.Drawing.Point(6, 29);
            this.statBox6way.Name = "statBox6way";
            this.statBox6way.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.statBox6way.Size = new System.Drawing.Size(1372, 24);
            this.statBox6way.TabIndex = 26;
            // 
            // rptBox6way
            // 
            this.rptBox6way.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rptBox6way.Font = new System.Drawing.Font("Courier New", 11.25F);
            this.rptBox6way.Location = new System.Drawing.Point(6, 59);
            this.rptBox6way.Multiline = true;
            this.rptBox6way.Name = "rptBox6way";
            this.rptBox6way.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.rptBox6way.Size = new System.Drawing.Size(1372, 408);
            this.rptBox6way.TabIndex = 27;
            this.rptBox6way.WordWrap = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(12, 236);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1392, 499);
            this.tabControl1.TabIndex = 28;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.progress2way);
            this.tabPage1.Controls.Add(this.rptBox2way);
            this.tabPage1.Controls.Add(this.statBox2way);
            this.tabPage1.Controls.Add(this.chk2WayTest);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1384, 473);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "2-Way";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.chk3WayTest);
            this.tabPage2.Controls.Add(this.rptBox3way);
            this.tabPage2.Controls.Add(this.statBox3way);
            this.tabPage2.Controls.Add(this.progress3way);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1384, 473);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "3-Way";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.rptBox4way);
            this.tabPage3.Controls.Add(this.statBox4way);
            this.tabPage3.Controls.Add(this.chk4WayTest);
            this.tabPage3.Controls.Add(this.progress4way);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1384, 473);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "4-Way";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.rptBox5way);
            this.tabPage4.Controls.Add(this.chk5WayTest);
            this.tabPage4.Controls.Add(this.progress5way);
            this.tabPage4.Controls.Add(this.statBox5way);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1384, 473);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "5-Way";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.rptBox6way);
            this.tabPage5.Controls.Add(this.chk6WayTest);
            this.tabPage5.Controls.Add(this.progress6way);
            this.tabPage5.Controls.Add(this.statBox6way);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1384, 473);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "6-Way";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // grpFileInfo
            // 
            this.grpFileInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpFileInfo.Controls.Add(this.label3);
            this.grpFileInfo.Controls.Add(this.btnTest);
            this.grpFileInfo.Controls.Add(this.label2);
            this.grpFileInfo.Controls.Add(this.label1);
            this.grpFileInfo.Controls.Add(this.btnLoadFaultFile);
            this.grpFileInfo.Controls.Add(this.txtFaultContents);
            this.grpFileInfo.Controls.Add(this.txtFaultInfo);
            this.grpFileInfo.Controls.Add(this.btnLoadNominalFile);
            this.grpFileInfo.Controls.Add(this.txtNominalInfo);
            this.grpFileInfo.Location = new System.Drawing.Point(12, 12);
            this.grpFileInfo.Name = "grpFileInfo";
            this.grpFileInfo.Size = new System.Drawing.Size(1392, 218);
            this.grpFileInfo.TabIndex = 29;
            this.grpFileInfo.TabStop = false;
            this.grpFileInfo.Text = "File Information";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Class File Contents:";
            // 
            // btnTest
            // 
            this.btnTest.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTest.Enabled = false;
            this.btnTest.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnTest.Location = new System.Drawing.Point(4, 179);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(1382, 21);
            this.btnTest.TabIndex = 18;
            this.btnTest.Text = "RUN";
            this.btnTest.UseVisualStyleBackColor = false;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Nominal File:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Class File:";
            // 
            // Faultloc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1400, 737);
            this.Controls.Add(this.grpFileInfo);
            this.Controls.Add(this.tabControl1);
            this.Name = "Faultloc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Class feature difference analysis";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.grpFileInfo.ResumeLayout(false);
            this.grpFileInfo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLoadFaultFile;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.TextBox txtFaultContents;
        private System.Windows.Forms.Button btnLoadNominalFile;
        private System.Windows.Forms.TextBox rptBox2way;
        private System.Windows.Forms.TextBox txtNominalInfo;
        private System.Windows.Forms.TextBox rptBox3way;
        private System.Windows.Forms.TextBox rptBox4way;
        private System.Windows.Forms.CheckBox chk2WayTest;
        private System.Windows.Forms.CheckBox chk3WayTest;
        private System.Windows.Forms.CheckBox chk4WayTest;
        private System.Windows.Forms.TextBox txtFaultInfo;
        private System.Windows.Forms.TextBox statBox2way;
        private System.Windows.Forms.TextBox statBox4way;
        private System.Windows.Forms.TextBox statBox3way;
        private System.Windows.Forms.ProgressBar progress2way;
        private System.Windows.Forms.ProgressBar progress3way;
        private System.Windows.Forms.ProgressBar progress4way;
        private System.Windows.Forms.CheckBox chk5WayTest;
        private System.Windows.Forms.ProgressBar progress5way;
        private System.Windows.Forms.TextBox statBox5way;
        private System.Windows.Forms.TextBox rptBox5way;
        private System.Windows.Forms.CheckBox chk6WayTest;
        private System.Windows.Forms.ProgressBar progress6way;
        private System.Windows.Forms.TextBox statBox6way;
        private System.Windows.Forms.TextBox rptBox6way;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox grpFileInfo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.Label label3;
    }
}

