import subprocess
import os
import pandas as pd
#import IPM
import sys

'''
Encoded values are translated back to their original values,
using the original input model csv source file.
arg1 = csv IPM file;   arg2 = int value csv file (transl from);   arg3 = str value csv vile (transl to)
'''
parameters = pd.read_csv(sys.argv[1], dtype=str)
int_csv = pd.read_csv(sys.argv[2], skiprows=8)

for index, col in enumerate(parameters.columns.values):
   parameter_map = parameters[col].dropna().to_dict()
   int_csv[col] = int_csv[col].map(parameter_map)

int_csv.to_csv(sys.argv[3])

